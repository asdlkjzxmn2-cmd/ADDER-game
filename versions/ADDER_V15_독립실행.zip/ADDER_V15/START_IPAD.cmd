@echo off
cd /d "%~dp0"
where node >nul 2>nul
if not errorlevel 1 (
  node server.cjs
) else if exist "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" (
  "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" server.cjs
) else (
  echo Node.js is required for iPad Wi-Fi mode. Install Node.js LTS from https://nodejs.org
  echo PC offline play: open ADDER_V15.html in Chrome or Edge.
)
pause

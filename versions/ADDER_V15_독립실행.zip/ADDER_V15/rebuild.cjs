const fs=require('node:fs'),path=require('node:path');
const read=n=>fs.readFileSync(path.join(__dirname,'source',n),'utf8');
const logic='globalThis.AdderLogic=(()=>{\n'+read('logic.js').replace(/export /g,'')+'\nreturn {meta,setup,validateAction,applyAction,isGameOver,viewFor};})();';
const scripts=[logic,read('local-runtime.js'),read('client.js')].map(s=>'<script>\n'+s.replace(/<\/script/gi,'<\\/script')+'\n</script>').join('\n');
const html=read('template.html').replace('<!--STYLE-->',()=>'<style>\n'+read('style.css')+'\n</style>').replace('<!--SCRIPTS-->',()=>scripts);
fs.writeFileSync(path.join(__dirname,'ADDER_V15.html'),html);console.log('ADDER_V15.html updated');

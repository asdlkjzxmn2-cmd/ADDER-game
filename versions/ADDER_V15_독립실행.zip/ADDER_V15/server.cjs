// Local static server: serves only the standalone game, never other PC files.
const http=require('node:http'),fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const port=8133;
const server=http.createServer((req,res)=>{
 const p=new URL(req.url,'http://localhost').pathname;
 if(p!=='/'&&p!=='/ADDER_V15.html'){res.writeHead(404);res.end();return;}
 res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});
 fs.createReadStream(path.join(__dirname,'ADDER_V15.html')).pipe(res);
});
server.on('error',e=>{console.error(e.message);process.exitCode=1});
server.listen(port,'0.0.0.0',()=>{
 console.log('ADDER V15 - Keep this window open. Ctrl+C to stop.');
 console.log('PC: http://localhost:'+port);
 for(const list of Object.values(os.networkInterfaces()))for(const n of list||[])if(n.family==='IPv4'&&!n.internal)console.log('iPad (same Wi-Fi): http://'+n.address+':'+port);
});
